#!/usr/bin/env node
/**
 * Entorno de pruebas web de extremo a extremo con un solo comando.
 *
 *   1. Compila core y api (si hace falta).
 *   2. Exporta la app web apuntando a la API local.
 *   3. Arranca la API (con CORS y datos persistentes en un JSON local).
 *   4. Sirve la web con las cabeceras de aislamiento que necesita SQLite.
 *
 * Uso: npm run web:test        → web en http://localhost:8080, API en :8787
 * Variables: WEB_PORT, API_PORT, SKIP_EXPORT=1 (reutiliza apps/mobile/dist)
 */

import { spawn, spawnSync } from 'node:child_process';
import { existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(import.meta.url), '..', '..');
const MOBILE = join(ROOT, 'apps', 'mobile');
const webPort = process.env.WEB_PORT ?? '8080';
const apiPort = process.env.API_PORT ?? '8787';
const npx = process.platform === 'win32' ? 'npx.cmd' : 'npx';
const npm = process.platform === 'win32' ? 'npm.cmd' : 'npm';

function run(command, args, options) {
  const result = spawnSync(command, args, { stdio: 'inherit', ...options });
  if (result.status !== 0) {
    console.error(`Falló: ${command} ${args.join(' ')}`);
    process.exit(result.status ?? 1);
  }
}

if (!existsSync(join(ROOT, 'packages', 'core', 'dist')) || !existsSync(join(ROOT, 'apps', 'api', 'dist'))) {
  run(npm, ['run', 'build'], { cwd: ROOT });
}

if (process.env.SKIP_EXPORT !== '1' || !existsSync(join(MOBILE, 'dist', 'index.html'))) {
  run(npx, ['expo', 'export', '--platform', 'web', '--output-dir', 'dist', '--clear'], {
    cwd: MOBILE,
    env: { ...process.env, EXPO_PUBLIC_API_BASE_URL: `http://localhost:${apiPort}` },
  });
}

const dataDir = join(ROOT, 'apps', 'api', '.data');
mkdirSync(dataDir, { recursive: true });

const children = [
  spawn(process.execPath, [join(ROOT, 'apps', 'api', 'dist', 'index.js')], {
    stdio: 'inherit',
    env: {
      ...process.env,
      PORT: apiPort,
      DATA_FILE: join(dataDir, 'progress.json'),
      CORS_ORIGIN: process.env.CORS_ORIGIN ?? `http://localhost:${webPort},http://127.0.0.1:${webPort}`,
    },
  }),
  spawn(process.execPath, [join(ROOT, 'scripts', 'serve-web.mjs'), join(MOBILE, 'dist'), webPort], {
    stdio: 'inherit',
  }),
];

console.warn(`\nListo. Abra http://localhost:${webPort}  (API: http://localhost:${apiPort}/health)\n`);

const stop = () => {
  for (const child of children) {
    child.kill('SIGTERM');
  }
  process.exit(0);
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);
for (const child of children) {
  child.on('exit', (code) => {
    if (code) {
      console.error(`Un proceso terminó con código ${code}; deteniendo el entorno.`);
      stop();
    }
  });
}
