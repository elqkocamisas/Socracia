#!/usr/bin/env node
/**
 * Servidor estático para la exportación web de la app (`apps/mobile/dist`).
 *
 * Por qué no vale cualquier servidor: `expo-sqlite` en navegador usa
 * WebAssembly con memoria compartida, que exige aislamiento de origen cruzado
 * (`COOP: same-origin` + `COEP: require-corp`). Sin esas cabeceras la base de
 * datos no arranca o el progreso no persiste. Este servidor las envía, sirve
 * `.wasm` con su tipo MIME y cae a `index.html` para cualquier ruta (SPA).
 *
 * Uso: node scripts/serve-web.mjs [directorio] [puerto]
 *      (por defecto apps/mobile/dist y 8080; también PORT y WEB_DIR)
 */

import { createServer } from 'node:http';
import { existsSync, statSync, createReadStream } from 'node:fs';
import { extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = join(fileURLToPath(import.meta.url), '..', '..');
const dir = resolve(process.argv[2] ?? process.env.WEB_DIR ?? join(ROOT, 'apps', 'mobile', 'dist'));
const port = Number(process.argv[3] ?? process.env.PORT ?? 8080);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.wasm': 'application/wasm',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.svg': 'image/svg+xml',
  '.ttf': 'font/ttf',
  '.map': 'application/json',
  '.txt': 'text/plain; charset=utf-8',
};

if (!existsSync(join(dir, 'index.html'))) {
  console.error(`No hay exportación web en ${dir}. Ejecute: npm run web:export`);
  process.exit(1);
}

function resolveFile(urlPath) {
  const clean = normalize(decodeURIComponent(urlPath.split('?')[0])).replace(/^([/\\])+/, '');
  const candidate = resolve(dir, clean);
  // Evita salir del directorio con `..`.
  if (candidate !== dir && !candidate.startsWith(dir + sep)) {
    return null;
  }
  if (existsSync(candidate) && statSync(candidate).isFile()) {
    return candidate;
  }
  // Rutas sin extensión: fallback de SPA.
  return extname(clean) ? null : join(dir, 'index.html');
}

const server = createServer((req, res) => {
  const headers = {
    'cross-origin-opener-policy': 'same-origin',
    'cross-origin-embedder-policy': 'require-corp',
    'cross-origin-resource-policy': 'same-origin',
    'cache-control': 'no-cache',
  };
  let file = null;
  try {
    file = resolveFile(req.url ?? '/');
  } catch {
    file = null;
  }
  if (!file) {
    res.writeHead(404, { ...headers, 'content-type': 'text/plain; charset=utf-8' });
    res.end('No encontrado');
    return;
  }
  res.writeHead(200, {
    ...headers,
    'content-type': MIME[extname(file).toLowerCase()] ?? 'application/octet-stream',
  });
  createReadStream(file).pipe(res);
});

server.listen(port, () => {
  console.warn(`Socracia web sirviendo ${dir} en http://localhost:${port}`);
});
