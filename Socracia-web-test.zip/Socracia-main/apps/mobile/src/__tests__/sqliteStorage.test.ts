import type { SQLiteDatabase } from 'expo-sqlite';

import type {
  AnswerEvaluation,
  KnowledgeChunk,
  KnowledgeDocument,
  ReviewState,
  SocraticQuestion,
} from '@socracia/core';

import { migrate } from '../storage/schema';
import { sqliteStorage } from '../storage/sqliteStorage';
import { createNodeSqliteAdapter, type NodeSqliteAdapter } from './helpers/nodeSqliteAdapter';

const NOW = 1_700_000_000_000;

/**
 * Estas pruebas ejecutan el SQL real del adaptador móvil sobre `node:sqlite`.
 * No hay doble de la capa de datos: solo se sustituye el enlace al driver.
 */
async function openTestStorage() {
  const adapter: NodeSqliteAdapter = createNodeSqliteAdapter();
  const db = adapter as unknown as SQLiteDatabase;
  await migrate(db);
  return { storage: sqliteStorage(db), adapter };
}

const document: KnowledgeDocument = {
  id: 'd1',
  title: 'Tema 1',
  mimeType: 'text/plain',
  sourceKind: 'document',
  uri: 'file:///t.txt',
  sizeBytes: 120,
  ingestedAt: NOW,
  cloudConsent: false,
};

const question: SocraticQuestion = {
  id: 'c1:q0',
  conceptId: 'c1',
  prompt: '¿Por qué?',
  move: 'causa',
  level: 'comprender',
  expectedAnswer: 'Respuesta de referencia suficientemente larga para evaluar.',
  keyTerms: ['clave'],
  citation: {
    documentId: 'd1',
    documentTitle: 'Tema 1',
    chunkId: 'd1:0',
    excerpt: 'x',
    charStart: 0,
    charEnd: 10,
  },
  difficulty: 0.3,
};

const evaluation: AnswerEvaluation = {
  questionId: 'c1:q0',
  conceptId: 'c1',
  verdict: 'correcta',
  score: 0.9,
  matchedKeyTerms: ['clave'],
  missingKeyTerms: [],
  feedback: 'bien',
};

const review: ReviewState = {
  conceptId: 'c1',
  ease: 2.6,
  intervalDays: 1,
  repetitions: 1,
  dueAt: NOW + 86_400_000,
  lastReviewedAt: NOW,
};

function chunk(documentId: string, ordinal: number): KnowledgeChunk {
  const text = `fragmento ${ordinal}`;
  return {
    id: `${documentId}:${ordinal}`,
    documentId,
    text,
    ordinal,
    charStart: ordinal * 10,
    charEnd: ordinal * 10 + text.length,
  };
}

describe('migrate', () => {
  it('es idempotente', async () => {
    const adapter = createNodeSqliteAdapter();
    const db = adapter as unknown as SQLiteDatabase;
    await migrate(db);
    await migrate(db);
    const tables = await adapter.getAllAsync<{ name: string }>(
      "SELECT name FROM sqlite_master WHERE type = 'table' ORDER BY name;",
    );
    const names = tables.map((t) => t.name);
    expect(names).toEqual(
      expect.arrayContaining([
        'documents',
        'curricula',
        'questions',
        'sessions',
        'evaluations',
        'review_states',
        'gap_profiles',
      ]),
    );
  });
});

describe('SqliteDocumentRepository', () => {
  it('guarda, lee y lista documentos con el SQL real', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveDocument(document);
    await storage.documents.saveDocument({ ...document, id: 'd0', ingestedAt: NOW - 5000 });

    expect(await storage.documents.getDocument('d1')).toEqual(document);
    expect(await storage.documents.getDocument('nope')).toBeNull();

    const list = await storage.documents.listDocuments();
    expect(list.map((d) => d.id)).toEqual(['d1', 'd0']);
  });

  it('actualiza un documento existente sin duplicar', async () => {
    const { storage, adapter } = await openTestStorage();
    await storage.documents.saveDocument(document);
    await storage.documents.saveDocument({ ...document, title: 'Tema 1 revisado' });
    const rows = await adapter.getAllAsync<{ c: number }>('SELECT COUNT(*) AS c FROM documents;');
    expect(rows[0]?.c).toBe(1);
    expect((await storage.documents.getDocument('d1'))?.title).toBe('Tema 1 revisado');
  });

  it('guarda y recupera temarios', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveCurriculum({
      id: 'd1',
      title: 'Tema 1',
      topics: [{ id: 't1', title: 'Uno', summary: '' }],
      concepts: [],
      createdAt: NOW,
    });
    const record = await storage.documents.getCurriculum('d1');
    expect(record?.topics[0]?.title).toBe('Uno');
    expect(await storage.documents.listCurricula()).toHaveLength(1);
  });

  it('borra en cascada documento, temario y preguntas', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveDocument(document);
    await storage.documents.saveCurriculum({
      id: 'd1',
      title: 'T',
      topics: [],
      concepts: [],
      createdAt: NOW,
    });
    await storage.questions.saveQuestions([question]);

    await storage.documents.deleteDocument('d1');

    expect(await storage.documents.getDocument('d1')).toBeNull();
    expect(await storage.documents.getCurriculum('d1')).toBeNull();
    expect(await storage.questions.listByDocument('d1')).toHaveLength(0);
  });

  it('guarda y recupera fragmentos en orden de aparición', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveChunks([chunk('d1', 1), chunk('d1', 0)]);

    const chunks = await storage.documents.listChunks('d1');

    expect(chunks.map((item) => item.ordinal)).toEqual([0, 1]);
    expect(chunks[0]?.text).toBe('fragmento 0');
  });

  it('el upsert de fragmentos no duplica al reindexar', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveChunks([chunk('d1', 0)]);
    await storage.documents.saveChunks([chunk('d1', 0)]);

    expect(await storage.documents.listChunks('d1')).toHaveLength(1);
  });

  it('listAllChunks devuelve los fragmentos de todos los documentos', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveChunks([chunk('d1', 0)]);
    await storage.documents.saveChunks([chunk('d2', 0)]);

    expect(await storage.documents.listAllChunks()).toHaveLength(2);
  });

  it('borrar un documento elimina también sus fragmentos', async () => {
    const { storage } = await openTestStorage();
    await storage.documents.saveDocument(document);
    await storage.documents.saveChunks([chunk('d1', 0)]);

    await storage.documents.deleteDocument('d1');

    expect(await storage.documents.listAllChunks()).toHaveLength(0);
  });
});

describe('SqliteQuestionRepository', () => {
  it('ordena por dificultad y filtra por documento con el SQL real', async () => {
    const { storage } = await openTestStorage();
    await storage.questions.saveQuestions([
      { ...question, id: 'c1:q1', difficulty: 0.8 },
      { ...question, id: 'c1:q0', difficulty: 0.3 },
      {
        ...question,
        id: 'c2:q0',
        conceptId: 'c2',
        citation: { ...question.citation, documentId: 'd2' },
      },
    ]);

    expect((await storage.questions.listByConcept('c1')).map((q) => q.id)).toEqual([
      'c1:q0',
      'c1:q1',
    ]);
    expect((await storage.questions.listByDocument('d2')).map((q) => q.id)).toEqual(['c2:q0']);
  });

  it('el upsert reemplaza la pregunta', async () => {
    const { storage, adapter } = await openTestStorage();
    await storage.questions.saveQuestions([question]);
    await storage.questions.saveQuestions([{ ...question, difficulty: 0.99 }]);
    const rows = await adapter.getAllAsync<{ c: number }>('SELECT COUNT(*) AS c FROM questions;');
    expect(rows[0]?.c).toBe(1);
    expect((await storage.questions.listByConcept('c1'))[0]?.difficulty).toBe(0.99);
  });
});

describe('SqliteProgressRepository', () => {
  it('persiste sesiones por usuario', async () => {
    const { storage } = await openTestStorage();
    await storage.progress.saveSession({
      id: 's1',
      userId: 'u1',
      topicId: 't1',
      startedAt: NOW,
      finishedAt: null,
      questionIds: ['c1:q0'],
      answers: [],
    });
    expect((await storage.progress.listSessions('u1')).map((s) => s.id)).toEqual(['s1']);
    expect(await storage.progress.getSession('s1')).not.toBeNull();
    expect(await storage.progress.listSessions('otro')).toHaveLength(0);
  });

  it('acumula evaluaciones con secuencia creciente', async () => {
    const { storage, adapter } = await openTestStorage();
    await storage.progress.appendEvaluations('u1', [evaluation]);
    await storage.progress.appendEvaluations('u1', [
      { ...evaluation, verdict: 'incorrecta' },
      { ...evaluation, verdict: 'parcial' },
    ]);

    const list = await storage.progress.listEvaluations('u1');
    expect(list.map((e) => e.verdict)).toEqual(['correcta', 'incorrecta', 'parcial']);

    const seqs = await adapter.getAllAsync<{ seq: number }>(
      'SELECT seq FROM evaluations WHERE user_id = ? ORDER BY seq;',
      ['u1'],
    );
    expect(seqs.map((row) => row.seq)).toEqual([1, 2, 3]);
  });

  it('no inserta nada si la lista de evaluaciones está vacía', async () => {
    const { storage, adapter } = await openTestStorage();
    await storage.progress.appendEvaluations('u1', []);
    const rows = await adapter.getAllAsync<{ c: number }>('SELECT COUNT(*) AS c FROM evaluations;');
    expect(rows[0]?.c).toBe(0);
  });

  it('hace upsert del estado de repaso por usuario y concepto', async () => {
    const { storage, adapter } = await openTestStorage();
    await storage.progress.saveReviewStates('u1', [review]);
    await storage.progress.saveReviewStates('u1', [{ ...review, repetitions: 5 }]);
    await storage.progress.saveReviewStates('u2', [review]);

    const rows = await adapter.getAllAsync<{ c: number }>(
      'SELECT COUNT(*) AS c FROM review_states;',
    );
    expect(rows[0]?.c).toBe(2);
    expect((await storage.progress.listReviewStates('u1'))[0]?.repetitions).toBe(5);
  });

  it('hace upsert del perfil de lagunas', async () => {
    const { storage, adapter } = await openTestStorage();
    await storage.progress.saveGapProfile({
      userId: 'u1',
      generatedAt: NOW,
      gaps: [],
      recommendedReview: [],
    });
    await storage.progress.saveGapProfile({
      userId: 'u1',
      generatedAt: NOW + 1,
      gaps: [],
      recommendedReview: ['c1'],
    });
    const rows = await adapter.getAllAsync<{ c: number }>(
      'SELECT COUNT(*) AS c FROM gap_profiles;',
    );
    expect(rows[0]?.c).toBe(1);
    expect((await storage.progress.getGapProfile('u1'))?.recommendedReview).toEqual(['c1']);
  });
});

describe('SqliteProgressRepository.removeConcepts', () => {
  it('elimina evaluaciones y repaso del concepto borrado y conserva el resto', async () => {
    const { storage } = await openTestStorage();
    await storage.progress.appendEvaluations('u1', [
      evaluation,
      { ...evaluation, questionId: 'c2:q0', conceptId: 'c2' },
      { ...evaluation, questionId: 'c3:q0', conceptId: 'c3' },
    ]);
    await storage.progress.saveReviewStates('u1', [
      review,
      { ...review, conceptId: 'c2' },
      { ...review, conceptId: 'c3' },
    ]);

    await storage.progress.removeConcepts('u1', ['c2']);

    const evaluations = await storage.progress.listEvaluations('u1');
    expect(evaluations.map((item) => item.conceptId)).toEqual(['c1', 'c3']);
    expect((await storage.progress.listReviewStates('u1')).map((s) => s.conceptId)).toEqual([
      'c1',
      'c3',
    ]);
  });

  it('conserva el orden del historial al filtrar', async () => {
    const { storage } = await openTestStorage();
    // Cinco respuestas seguidas: al borrar la del medio, las demás deben seguir
    // en el mismo orden, que es el de `seq`.
    for (let index = 0; index < 5; index += 1) {
      await storage.progress.appendEvaluations('u1', [
        { ...evaluation, questionId: `q${index}`, conceptId: `c${index}` },
      ]);
    }

    await storage.progress.removeConcepts('u1', ['c2']);

    const evaluations = await storage.progress.listEvaluations('u1');
    expect(evaluations.map((item) => item.conceptId)).toEqual(['c0', 'c1', 'c3', 'c4']);
  });

  it('no altera nada si la lista de conceptos está vacía', async () => {
    const { storage } = await openTestStorage();
    await storage.progress.appendEvaluations('u1', [evaluation]);

    await storage.progress.removeConcepts('u1', []);

    expect(await storage.progress.listEvaluations('u1')).toHaveLength(1);
  });

  it('limpia lagunas y recomendaciones del perfil guardado', async () => {
    const { storage } = await openTestStorage();
    await storage.progress.saveGapProfile({
      userId: 'u1',
      generatedAt: NOW,
      gaps: [
        {
          conceptId: 'c1',
          conceptLabel: 'Uno',
          severity: 0.8,
          attempts: 2,
          lastEvaluatedAt: NOW,
          rationale: 'falló',
        },
        {
          conceptId: 'c2',
          conceptLabel: 'Dos',
          severity: 0.5,
          attempts: 1,
          lastEvaluatedAt: NOW,
          rationale: 'falló',
        },
      ],
      recommendedReview: ['c1', 'c2'],
    });

    await storage.progress.removeConcepts('u1', ['c1']);

    const profile = await storage.progress.getGapProfile('u1');
    expect(profile?.gaps.map((gap) => gap.conceptId)).toEqual(['c2']);
    expect(profile?.recommendedReview).toEqual(['c2']);
  });
});
