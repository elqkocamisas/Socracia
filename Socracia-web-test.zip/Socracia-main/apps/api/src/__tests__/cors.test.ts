import { AuthService } from '../auth';
import { InMemoryProgressStore } from '../store';
import { createApiServer } from '../server';

import { startApi } from './helpers/apiHarness';

/**
 * CORS: la app web se sirve desde otro origen que la API, así que el navegador
 * exige preflight y cabeceras explícitas. Estas pruebas hablan HTTP real.
 */
async function withApi<T>(
  corsOrigin: string | undefined,
  body: (baseUrl: string) => Promise<T>,
): Promise<T> {
  const server = createApiServer({
    auth: new AuthService(),
    store: new InMemoryProgressStore(),
    corsOrigin,
  });
  const running = await startApi(server);
  try {
    return await body(running.baseUrl);
  } finally {
    await running.close();
  }
}

describe('CORS de la API', () => {
  it('responde al preflight con 204 y las cabeceras necesarias', async () => {
    await withApi('*', async (baseUrl) => {
      const res = await fetch(`${baseUrl}/sync/push`, {
        method: 'OPTIONS',
        headers: {
          origin: 'http://localhost:8081',
          'access-control-request-method': 'POST',
          'access-control-request-headers': 'authorization, content-type',
        },
      });
      expect(res.status).toBe(204);
      expect(res.headers.get('access-control-allow-origin')).toBe('*');
      expect(res.headers.get('access-control-allow-headers')).toContain('authorization');
      expect(res.headers.get('access-control-allow-methods')).toContain('DELETE');
    });
  });

  it('añade CORS y CORP a las respuestas normales', async () => {
    await withApi('*', async (baseUrl) => {
      const res = await fetch(`${baseUrl}/health`, { headers: { origin: 'http://localhost:8081' } });
      expect(res.status).toBe(200);
      expect(res.headers.get('access-control-allow-origin')).toBe('*');
      expect(res.headers.get('cross-origin-resource-policy')).toBe('cross-origin');
    });
  });

  it('con lista de orígenes, solo refleja el origen autorizado', async () => {
    await withApi('http://localhost:8081, https://app.example.com', async (baseUrl) => {
      const allowed = await fetch(`${baseUrl}/health`, {
        headers: { origin: 'https://app.example.com' },
      });
      expect(allowed.headers.get('access-control-allow-origin')).toBe('https://app.example.com');
      expect(allowed.headers.get('vary')).toBe('Origin');

      const denied = await fetch(`${baseUrl}/health`, { headers: { origin: 'https://evil.test' } });
      expect(denied.status).toBe(200);
      expect(denied.headers.get('access-control-allow-origin')).toBeNull();
    });
  });

  it('sin configuración no emite cabeceras CORS', async () => {
    await withApi(undefined, async (baseUrl) => {
      const res = await fetch(`${baseUrl}/health`, { headers: { origin: 'http://localhost:8081' } });
      expect(res.status).toBe(200);
      expect(res.headers.get('access-control-allow-origin')).toBeNull();
    });
  });
});
