# Generar un APK instalable

## Opción A — botón en GitHub (sin cuenta de Expo)

1. Suba el repositorio a GitHub.
2. **Actions → «Generar APK (botón rojo)» → Run workflow.**
3. Al terminar (10–25 min), descargue `socracia-apk` desde el resumen de la
   ejecución, descomprima e instale `socracia.apk` en el móvil.

El APK sale firmado con la clave de depuración de Expo: vale para probar, no
para Google Play.

## Opción B — desde su máquina, en la nube de Expo

```bash
npm install
npx eas-cli login      # cuenta gratuita de Expo
npm run apk            # perfil `preview` de eas.json → APK
```

EAS devuelve un enlace de descarga del APK.

## Instalar

Android no permite que un APK se instale ni se ejecute solo: hay que abrir el
archivo y autorizar «Instalar apps desconocidas» para el navegador o gestor de
archivos. Después queda como una app normal.

## Nota

Sin `EXPO_PUBLIC_API_BASE_URL` la app apunta a `localhost`: funciona sin cuenta
y sin conexión, pero la sincronización no. Para sincronizar, indique la URL
pública (HTTPS) de la API al lanzar el workflow.
