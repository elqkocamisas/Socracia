# Pruebas en web

La misma app de Expo se ejecuta en navegador con `react-native-web`. Sirve para
probar el recorrido completo (importar → responder → progreso → cuenta y
sincronización) sin simulador.

## Arranque rápido

```bash
npm install
npm run web:test
```

Abre <http://localhost:8080>. El comando compila, exporta la web apuntando a la
API local (`:8787`), arranca la API con datos persistentes en
`apps/api/.data/progress.json` y sirve la web con las cabeceras necesarias.
`Ctrl+C` detiene ambos procesos.

Variables: `WEB_PORT`, `API_PORT`, `CORS_ORIGIN`, `SKIP_EXPORT=1` (reutiliza
`apps/mobile/dist`).

## Solo la app, sin backend

```bash
npm run web          # servidor de desarrollo de Expo
```

La app funciona sin cuenta y sin conexión; la sincronización es opcional.

## Por qué hay un servidor propio

- **COOP/COEP:** `expo-sqlite` en navegador usa WebAssembly con memoria
  compartida y exige `Cross-Origin-Opener-Policy: same-origin` y
  `Cross-Origin-Embedder-Policy: require-corp`. `scripts/serve-web.mjs` los envía.
- **CORS:** la web y la API viven en orígenes distintos. La API responde al
  preflight y envía `Cross-Origin-Resource-Policy: cross-origin` (necesario con
  COEP). `CORS_ORIGIN` admite `*` o una lista separada por comas; el valor por
  defecto del entrypoint es `*` para pruebas. **En producción, fije el dominio.**
- La API autentica con `Authorization: Bearer`, no con cookies.

## Lista de comprobación manual

1. Importar un `.txt`/`.md`/`.pdf` y ver que se generan conceptos.
2. Responder una pregunta y recibir evaluación.
3. Recargar la página: el progreso debe seguir ahí (valida SQLite en web).
4. Crear cuenta, sincronizar y entrar desde otro navegador: mismo progreso.
5. Eliminar la cuenta: la sesión deja de ser válida.

## Limitaciones conocidas

- `expo-sqlite` en web es experimental; si el progreso no persiste, revise en
  las herramientas del navegador que la página está aislada
  (`crossOriginIsolated === true`).
- El render es de navegador: la tipografía y las sombras pueden diferir de
  iOS/Android.
